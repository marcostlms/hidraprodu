import React, { useEffect, useMemo, useState } from "react";
import { Navigate, Link } from "react-router-dom";
import { api, formatApiError, resolveImage } from "@/lib/api";
import { useAuth } from "@/context/AuthContext";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { toast } from "sonner";
import { Plus, Pencil, Trash2, LogOut, Search, Upload, Link as LinkIcon, Package, Inbox, Mail } from "lucide-react";

const EMPTY_FORM = {
  code: "",
  name: "",
  category: "",
  brand: "",
  description: "",
  image_url: "",
  featured: false,
  stock: "available",
};

export default function AdminDashboard() {
  const { user, loading: authLoading, logout } = useAuth();
  const [products, setProducts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState("");
  const [filterCat, setFilterCat] = useState("all");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState(null); // product being edited
  const [form, setForm] = useState(EMPTY_FORM);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [imgMode, setImgMode] = useState("url"); // "url" | "upload"
  const [confirmDel, setConfirmDel] = useState(null);
  const [view, setView] = useState("products"); // "products" | "messages"
  const [messages, setMessages] = useState([]);
  const [msgLoading, setMsgLoading] = useState(false);
  const unread = useMemo(() => messages.filter((m) => !m.read).length, [messages]);

  const loadMessages = async () => {
    setMsgLoading(true);
    try {
      const { data } = await api.get("/contact");
      setMessages(data);
    } catch (err) {
      toast.error(formatApiError(err));
    } finally {
      setMsgLoading(false);
    }
  };

  useEffect(() => {
    if (user) loadMessages();
  }, [user]);

  const markRead = async (m) => {
    if (m.read) return;
    try {
      await api.patch(`/contact/${m.id}/read`);
      setMessages((list) => list.map((x) => (x.id === m.id ? { ...x, read: true } : x)));
    } catch {}
  };

  const deleteMessage = async (id) => {
    try {
      await api.delete(`/contact/${id}`);
      setMessages((list) => list.filter((x) => x.id !== id));
      toast.success("Mensagem removida");
    } catch (err) {
      toast.error(formatApiError(err));
    }
  };

  const refresh = async () => {
    setLoading(true);
    try {
      const [p, c] = await Promise.all([api.get("/products"), api.get("/categories")]);
      setProducts(p.data);
      setCategories(c.data);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (user) refresh();
  }, [user]);

  const filtered = useMemo(() => {
    let list = products;
    if (filterCat !== "all") list = list.filter((p) => p.category === filterCat);
    if (query.trim()) {
      const q = query.trim().toLowerCase();
      list = list.filter((p) => p.name.toLowerCase().includes(q) || p.code.toLowerCase().includes(q));
    }
    return list;
  }, [products, query, filterCat]);

  if (authLoading) return <div className="min-h-screen bg-[#f8f6eb]" />;
  if (!user) return <Navigate to="/admin/login" replace />;

  const openCreate = () => {
    setEditing(null);
    setForm({ ...EMPTY_FORM, category: categories[0]?.slug || "" });
    setImgMode("url");
    setDialogOpen(true);
  };

  const openEdit = (p) => {
    setEditing(p);
    setForm({
      code: p.code,
      name: p.name,
      category: p.category,
      brand: p.brand || "",
      description: p.description || "",
      image_url: p.image_url || "",
      featured: !!p.featured,
      stock: p.stock || "available",
    });
    setImgMode("url");
    setDialogOpen(true);
  };

  const handleUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    try {
      const fd = new FormData();
      fd.append("file", file);
      const { data } = await api.post("/upload", fd, { headers: { "Content-Type": "multipart/form-data" } });
      setForm((f) => ({ ...f, image_url: data.url }));
      toast.success("Imagem enviada");
    } catch (err) {
      toast.error(formatApiError(err));
    } finally {
      setUploading(false);
    }
  };

  const save = async (e) => {
    e.preventDefault();
    if (!form.code.trim() || !form.name.trim() || !form.category) {
      toast.error("Preencha código, nome e categoria");
      return;
    }
    setSaving(true);
    try {
      if (editing) {
        await api.put(`/products/${editing.id}`, form);
        toast.success("Produto atualizado");
      } else {
        await api.post("/products", form);
        toast.success("Produto cadastrado");
      }
      setDialogOpen(false);
      await refresh();
    } catch (err) {
      toast.error(formatApiError(err));
    } finally {
      setSaving(false);
    }
  };

  const doDelete = async () => {
    if (!confirmDel) return;
    try {
      await api.delete(`/products/${confirmDel.id}`);
      toast.success("Produto removido");
      setConfirmDel(null);
      await refresh();
    } catch (err) {
      toast.error(formatApiError(err));
    }
  };

  const catName = (slug) => categories.find((c) => c.slug === slug)?.name || slug;

  return (
    <div className="min-h-screen bg-[#f8f6eb]">
      {/* Top bar */}
      <header className="bg-[#3b3073] text-[#f8f6eb] border-b border-[#facb15]/30">
        <div className="mx-auto max-w-7xl px-6 py-4 flex items-center justify-between gap-4">
          <Link to="/" className="flex items-center gap-3">
            <span className="inline-flex items-center bg-[#f8f6eb] rounded-lg px-2.5 py-1.5 shadow">
              <img src="/hidrara/logo.jpg" alt="Hidrara" className="h-9 w-auto" />
            </span>
            <div className="hidden sm:block leading-tight border-l border-[#facb15]/30 pl-3">
              <div className="font-display text-sm font-extrabold">Painel Administrativo</div>
              <div className="text-[10px] uppercase tracking-widest text-[#facb15]">Catálogo de Produtos</div>
            </div>
          </Link>
          <div className="flex items-center gap-3">
            <span className="text-sm hidden sm:block text-[#f8f6eb]/70">{user.email}</span>
            <Button data-testid="admin-logout" onClick={logout} variant="ghost" className="text-[#f8f6eb] hover:bg-[#f8f6eb]/10 hover:text-[#facb15]">
              <LogOut className="w-4 h-4 mr-2" /> Sair
            </Button>
          </div>
        </div>
      </header>

      <div className="mx-auto max-w-7xl px-6 py-10">
        {/* Tabs */}
        <div className="flex items-center gap-2 mb-8 border-b border-[#3b3073]/10">
          <button
            data-testid="tab-products"
            onClick={() => setView("products")}
            className={`px-5 py-3 font-display font-bold text-sm uppercase tracking-widest border-b-2 transition-colors ${view === "products" ? "border-[#3b3073] text-[#3b3073]" : "border-transparent text-[#3b3073]/50 hover:text-[#3b3073]"}`}
          >
            <Package className="w-4 h-4 inline mr-2" />Produtos
          </button>
          <button
            data-testid="tab-messages"
            onClick={() => setView("messages")}
            className={`px-5 py-3 font-display font-bold text-sm uppercase tracking-widest border-b-2 transition-colors flex items-center gap-2 ${view === "messages" ? "border-[#3b3073] text-[#3b3073]" : "border-transparent text-[#3b3073]/50 hover:text-[#3b3073]"}`}
          >
            <Inbox className="w-4 h-4" />Mensagens
            {unread > 0 && (
              <span data-testid="unread-badge" className="ml-1 bg-[#facb15] text-[#3b3073] text-[10px] font-black px-2 py-0.5 rounded-full">{unread}</span>
            )}
          </button>
        </div>

        {view === "messages" ? (
          <MessagesView messages={messages} loading={msgLoading} onOpen={markRead} onDelete={deleteMessage} onRefresh={loadMessages} />
        ) : (
        <>
        {/* Header + toolbar */}
        <div className="flex flex-wrap items-end justify-between gap-4 mb-8">
          <div>
            <div className="text-xs uppercase tracking-widest text-[#3b3073]/60 font-bold">Catálogo</div>
            <h1 className="font-display text-4xl lg:text-5xl font-black text-[#3b3073] mt-1">Gerenciar Produtos</h1>
            <p className="text-[#3b3073]/70 mt-1 text-sm flex items-center gap-2">
              <Package className="w-4 h-4" /> {products.length} produtos cadastrados
            </p>
          </div>
          <Button data-testid="admin-add-product" onClick={openCreate} className="bg-[#3b3073] hover:bg-[#2a2255] text-[#facb15] font-bold h-12 px-6 rounded-full">
            <Plus className="w-4 h-4 mr-2" /> Novo produto
          </Button>
        </div>

        {/* Filters */}
        <div className="grid md:grid-cols-[1fr_260px] gap-3 mb-6">
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-[#3b3073]/50" />
            <Input
              data-testid="admin-search"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Buscar por nome ou código"
              className="pl-10 h-12 bg-white border-[#3b3073]/20"
            />
          </div>
          <Select value={filterCat} onValueChange={setFilterCat}>
            <SelectTrigger className="h-12 bg-white border-[#3b3073]/20" data-testid="admin-cat-filter">
              <SelectValue placeholder="Categoria" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todas as categorias</SelectItem>
              {categories.map((c) => (
                <SelectItem key={c.slug} value={c.slug}>{c.name}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Products table */}
        <div className="bg-white rounded-2xl border border-[#3b3073]/10 overflow-hidden">
          <div className="grid grid-cols-[80px_120px_1fr_140px_100px_120px] gap-4 px-5 py-3 bg-[#efeadc] text-[10px] uppercase tracking-widest font-bold text-[#3b3073]/70">
            <div>Imagem</div>
            <div>Código</div>
            <div>Produto</div>
            <div>Categoria</div>
            <div>Destaque</div>
            <div className="text-right">Ações</div>
          </div>
          {loading ? (
            <div className="p-10 text-center text-[#3b3073]/60">Carregando...</div>
          ) : filtered.length === 0 ? (
            <div className="p-10 text-center text-[#3b3073]/60" data-testid="admin-empty">Nenhum produto encontrado.</div>
          ) : (
            <div className="divide-y divide-[#3b3073]/5">
              {filtered.map((p) => (
                <div key={p.id} data-testid={`admin-row-${p.code}`} className="grid grid-cols-[80px_120px_1fr_140px_100px_120px] gap-4 px-5 py-3 items-center hover:bg-[#f8f6eb]/50">
                  <div className="w-14 h-14 rounded-lg overflow-hidden bg-[#efeadc]">
                    {p.image_url ? (
                      <img src={resolveImage(p.image_url)} alt="" className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-[#3b3073]/30 text-xs">n/a</div>
                    )}
                  </div>
                  <div className="font-mono text-xs font-bold text-[#3b3073]">{p.code}</div>
                  <div>
                    <div className="font-display font-bold text-[#3b3073]">{p.name}</div>
                    {p.brand && <div className="text-xs text-[#3b3073]/60">{p.brand}</div>}
                  </div>
                  <div className="text-sm text-[#3b3073]/80">{catName(p.category)}</div>
                  <div>
                    {p.featured ? <Badge className="bg-[#facb15] text-[#3b3073] hover:bg-[#facb15]">Sim</Badge> : <span className="text-xs text-[#3b3073]/40">—</span>}
                  </div>
                  <div className="flex justify-end gap-2">
                    <Button data-testid={`admin-edit-${p.code}`} size="icon" variant="ghost" onClick={() => openEdit(p)}>
                      <Pencil className="w-4 h-4 text-[#3b3073]" />
                    </Button>
                    <Button data-testid={`admin-delete-${p.code}`} size="icon" variant="ghost" onClick={() => setConfirmDel(p)}>
                      <Trash2 className="w-4 h-4 text-red-600" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
        </>
        )}
      </div>

      {/* Form dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl bg-white max-h-[90vh] overflow-y-auto" data-testid="admin-product-dialog">
          <DialogHeader>
            <DialogTitle className="font-display text-2xl text-[#3b3073]">
              {editing ? "Editar produto" : "Novo produto"}
            </DialogTitle>
            <DialogDescription>Preencha os dados. Código e nome são obrigatórios.</DialogDescription>
          </DialogHeader>
          <form onSubmit={save} className="space-y-4">
            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <Label className="text-[#3b3073] font-semibold">Código *</Label>
                <Input data-testid="form-code" required value={form.code} onChange={(e) => setForm({ ...form, code: e.target.value })} placeholder="Ex: P954208" className="mt-1.5" />
              </div>
              <div>
                <Label className="text-[#3b3073] font-semibold">Marca</Label>
                <Input data-testid="form-brand" value={form.brand} onChange={(e) => setForm({ ...form, brand: e.target.value })} placeholder="Ex: Parker" className="mt-1.5" />
              </div>
            </div>
            <div>
              <Label className="text-[#3b3073] font-semibold">Nome *</Label>
              <Input data-testid="form-name" required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Ex: Filtro Hidráulico Parker" className="mt-1.5" />
            </div>
            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <Label className="text-[#3b3073] font-semibold">Categoria *</Label>
                <Select value={form.category} onValueChange={(v) => setForm({ ...form, category: v })}>
                  <SelectTrigger data-testid="form-category" className="mt-1.5">
                    <SelectValue placeholder="Selecione..." />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map((c) => (
                      <SelectItem key={c.slug} value={c.slug}>{c.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-end gap-3 pb-2">
                <Switch data-testid="form-featured" checked={form.featured} onCheckedChange={(v) => setForm({ ...form, featured: v })} />
                <Label className="text-[#3b3073] font-semibold">Produto em destaque</Label>
              </div>
            </div>
            <div>
              <Label className="text-[#3b3073] font-semibold">Descrição</Label>
              <Textarea data-testid="form-description" rows={4} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} placeholder="Descrição técnica detalhada..." className="mt-1.5" />
            </div>
            {/* Image mode toggle */}
            <div>
              <Label className="text-[#3b3073] font-semibold">Imagem do produto</Label>
              <div className="flex gap-2 mt-2">
                <button type="button" onClick={() => setImgMode("url")} className={`px-4 py-1.5 rounded-full text-xs font-bold ${imgMode === "url" ? "bg-[#3b3073] text-[#facb15]" : "bg-[#3b3073]/10 text-[#3b3073]"}`} data-testid="form-img-url-mode">
                  <LinkIcon className="w-3 h-3 inline mr-1.5" /> URL externa
                </button>
                <button type="button" onClick={() => setImgMode("upload")} className={`px-4 py-1.5 rounded-full text-xs font-bold ${imgMode === "upload" ? "bg-[#3b3073] text-[#facb15]" : "bg-[#3b3073]/10 text-[#3b3073]"}`} data-testid="form-img-upload-mode">
                  <Upload className="w-3 h-3 inline mr-1.5" /> Upload
                </button>
              </div>
              {imgMode === "url" ? (
                <Input data-testid="form-image-url" value={form.image_url} onChange={(e) => setForm({ ...form, image_url: e.target.value })} placeholder="https://..." className="mt-2" />
              ) : (
                <div className="mt-2">
                  <input data-testid="form-image-file" type="file" accept="image/*" onChange={handleUpload} disabled={uploading}
                    className="block w-full text-sm text-[#3b3073] file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-bold file:bg-[#3b3073] file:text-[#facb15] hover:file:bg-[#2a2255]" />
                  {uploading && <div className="text-xs text-[#3b3073]/60 mt-2">Enviando...</div>}
                </div>
              )}
              {form.image_url && (
                <div className="mt-3 w-32 h-32 rounded-lg overflow-hidden bg-[#efeadc] border border-[#3b3073]/10">
                  <img src={resolveImage(form.image_url)} alt="preview" className="w-full h-full object-cover" />
                </div>
              )}
            </div>
            <DialogFooter className="pt-2">
              <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>Cancelar</Button>
              <Button data-testid="form-submit" disabled={saving} type="submit" className="bg-[#3b3073] hover:bg-[#2a2255] text-[#facb15] font-bold">
                {saving ? "Salvando..." : editing ? "Salvar alterações" : "Cadastrar produto"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Delete confirmation */}
      <Dialog open={!!confirmDel} onOpenChange={(v) => !v && setConfirmDel(null)}>
        <DialogContent className="bg-white">
          <DialogHeader>
            <DialogTitle className="font-display text-2xl text-[#3b3073]">Remover produto?</DialogTitle>
            <DialogDescription>
              Esta ação não pode ser desfeita. O produto <b>{confirmDel?.code} — {confirmDel?.name}</b> será excluído do catálogo.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setConfirmDel(null)}>Cancelar</Button>
            <Button data-testid="admin-confirm-delete" onClick={doDelete} className="bg-red-600 hover:bg-red-700 text-white">Remover</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function MessagesView({ messages, loading, onOpen, onDelete, onRefresh }) {
  const [open, setOpen] = useState(null);
  return (
    <div>
      <div className="flex flex-wrap items-end justify-between gap-4 mb-8">
        <div>
          <div className="text-xs uppercase tracking-widest text-[#3b3073]/60 font-bold">Caixa de entrada</div>
          <h1 className="font-display text-4xl lg:text-5xl font-black text-[#3b3073] mt-1">Mensagens do site</h1>
          <p className="text-[#3b3073]/70 mt-1 text-sm">{messages.length} mensagem(ns) recebida(s)</p>
        </div>
        <Button onClick={onRefresh} variant="outline" className="border-[#3b3073]/20 text-[#3b3073]" data-testid="messages-refresh">
          Atualizar
        </Button>
      </div>

      <div className="bg-white rounded-2xl border border-[#3b3073]/10 overflow-hidden">
        {loading ? (
          <div className="p-10 text-center text-[#3b3073]/60">Carregando...</div>
        ) : messages.length === 0 ? (
          <div className="p-12 text-center" data-testid="messages-empty">
            <Mail className="w-10 h-10 text-[#3b3073]/30 mx-auto mb-3" />
            <div className="text-[#3b3073]/60">Nenhuma mensagem recebida ainda.</div>
          </div>
        ) : (
          <div className="divide-y divide-[#3b3073]/5">
            {messages.map((m) => (
              <button
                key={m.id}
                type="button"
                data-testid={`message-${m.id}`}
                onClick={() => { onOpen(m); setOpen(m); }}
                className={`w-full text-left flex items-start gap-4 px-5 py-4 hover:bg-[#f8f6eb]/60 ${m.read ? "" : "bg-[#facb15]/5"}`}
              >
                <div className={`w-2 h-2 rounded-full mt-2 flex-shrink-0 ${m.read ? "bg-[#3b3073]/20" : "bg-[#facb15]"}`} />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-2">
                    <div className="font-display font-bold text-[#3b3073] truncate">{m.name}</div>
                    <div className="text-xs text-[#3b3073]/50 flex-shrink-0">{new Date(m.created_at).toLocaleString("pt-BR")}</div>
                  </div>
                  <div className="text-xs text-[#3b3073]/60 mt-0.5">{m.email}{m.phone && ` · ${m.phone}`}</div>
                  <div className="text-sm text-[#3b3073]/80 mt-1 line-clamp-2">{m.message}</div>
                </div>
              </button>
            ))}
          </div>
        )}
      </div>

      <Dialog open={!!open} onOpenChange={(v) => !v && setOpen(null)}>
        <DialogContent className="max-w-2xl bg-white" data-testid="message-dialog">
          <DialogHeader>
            <DialogTitle className="font-display text-2xl text-[#3b3073]">{open?.name}</DialogTitle>
            <DialogDescription>
              {open?.email}{open?.phone && ` · ${open.phone}`} · {open && new Date(open.created_at).toLocaleString("pt-BR")}
            </DialogDescription>
          </DialogHeader>
          <div className="whitespace-pre-wrap text-[#3b3073]/85 leading-relaxed border-t border-[#3b3073]/10 pt-4">
            {open?.message}
          </div>
          <DialogFooter className="pt-2 gap-2">
            <a
              href={`mailto:${open?.email}?subject=${encodeURIComponent("Re: Contato pelo site Hidrara")}`}
              className="inline-flex items-center justify-center bg-[#3b3073] hover:bg-[#2a2255] text-[#facb15] font-bold px-4 py-2 rounded-md text-sm"
              data-testid="message-reply"
            >
              Responder por e-mail
            </a>
            <Button
              variant="outline"
              className="border-red-200 text-red-600 hover:bg-red-50"
              data-testid="message-delete"
              onClick={() => { onDelete(open.id); setOpen(null); }}
            >
              Excluir
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

