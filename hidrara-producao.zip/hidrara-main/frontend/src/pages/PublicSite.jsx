import React, { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { api, formatApiError } from "@/lib/api";
import { toast } from "sonner";
import Navbar from "@/components/Navbar";
import ProductCard from "@/components/ProductCard";
import ProductDetailDialog from "@/components/ProductDetailDialog";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search, MapPin, Phone, Mail, Clock, Sprout, TreePine, Truck, Factory, Target, Eye, Star, Award } from "lucide-react";

const HIDRARA_WHATSAPP = "551635081300";
const HIDRARA_WA_MSG = encodeURIComponent(
  "Olá! Vim pelo site da Hidrara e gostaria de tirar uma dúvida / falar com o atendimento."
);
const WA_URL = `https://wa.me/${HIDRARA_WHATSAPP}?text=${HIDRARA_WA_MSG}`;

const SECTORS = [
  { icon: Sprout, name: "Agrícola", desc: "Soluções para colheitadeiras, tratores e implementos agrícolas." },
  { icon: TreePine, name: "Florestal", desc: "Componentes hidráulicos para máquinas florestais de alta performance." },
  { icon: Truck, name: "Transporte", desc: "Peças e serviços para frotas de caminhões e veículos pesados." },
  { icon: Factory, name: "Industrial", desc: "Sistemas hidráulicos e pneumáticos para plantas industriais." },
];

const PROJECTS = [
  { title: "Unidade Móvel de Filtragem", desc: "Serviço de filtragem de óleo hidráulico realizado no local do cliente, aumentando a vida útil dos equipamentos." },
  { title: "Projetos de Melhoria", desc: "Desenvolvimento de soluções personalizadas para otimização de sistemas hidráulicos e pneumáticos." },
  { title: "Sistema Parkrimp", desc: "Montagem de mangueiras hidráulicas com equipamento Parker Parkrimp, garantia total de qualidade." },
  { title: "Filtragem Industrial", desc: "Consultoria e implementação de sistemas de filtragem industrial de alta performance." },
];

const BRANDS = ["Parker", "Bosch Rexroth", "Eaton", "SKF", "Fleetguard", "Wega Filtros", "Donaldson", "Mann Filter", "Continental", "Gates", "FAG", "NTN"];

const CLIENTS = [
  { name: "Raízen", src: "/hidrara/client-raizen.webp" },
  { name: "Bunge", src: "/hidrara/client-bunge.webp" },
  { name: "Guarani", src: "/hidrara/client-guarani.webp" },
  { name: "Eldorado Brasil", src: "/hidrara/client-eldorado.webp" },
  { name: "Fibria", src: "/hidrara/client-fibria.webp" },
  { name: "International Paper", src: "/hidrara/client-intlpaper.webp" },
  { name: "Biosev", src: "/hidrara/client-biosev.webp" },
  { name: "Usina Santa Adélia", src: "/hidrara/client-santaadelia.webp" },
  { name: "Usina Santa Fé", src: "/hidrara/client-santafe.webp" },
  { name: "Usina Bela Vista", src: "/hidrara/client-belavista.webp" },
  { name: "Abengoa", src: "/hidrara/client-abengoa.webp" },
  { name: "Agroterenas", src: "/hidrara/client-agroterenas.webp" },
  { name: "Iaco Agrícola", src: "/hidrara/client-iaco.webp" },
  { name: "Ipiranga Agroindustrial", src: "/hidrara/client-ipiranga.webp" },
  { name: "Cerradinho", src: "/hidrara/client-cerradinho.webp" },
  { name: "Bevap Bioenergia", src: "/hidrara/client-bevap.webp" },
  { name: "Zaphir Agroenergia", src: "/hidrara/client-zaphir.webp" },
];

const TESTIMONIALS = [
  { text: "A Hidrara é parceira da nossa usina há mais de 10 anos. Atendimento rápido, produtos de qualidade e uma equipe técnica que realmente entende do assunto.", name: "Carlos Ferreira", role: "Gerente de Manutenção — Usina São João" },
  { text: "Nunca ficamos parados. A entrega expressa e a unidade móvel de filtragem da Hidrara mudaram a forma como cuidamos das nossas colheitadeiras.", name: "Marina Souza", role: "Diretora de Operações — Agro Pantanal" },
  { text: "Preço justo, produto original e prazo cumprido. É raro encontrar tudo isso em uma única empresa. Recomendo demais!", name: "Roberto Almeida", role: "Supervisor Técnico — Transportadora Aliança" },
];

export default function PublicSite() {
  const [info, setInfo] = useState(null);
  const [categories, setCategories] = useState([]);
  const [products, setProducts] = useState([]);
  const [query, setQuery] = useState("");
  const [activeCat, setActiveCat] = useState("all");
  const [selected, setSelected] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const [i, c, p] = await Promise.all([
          api.get("/site/info"),
          api.get("/categories"),
          api.get("/products"),
        ]);
        setInfo(i.data);
        setCategories(c.data);
        setProducts(p.data);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const filtered = useMemo(() => {
    let list = products;
    if (activeCat !== "all") list = list.filter((p) => p.category === activeCat);
    if (query.trim()) {
      const q = query.trim().toLowerCase();
      list = list.filter(
        (p) => p.name.toLowerCase().includes(q) || p.code.toLowerCase().includes(q) || (p.description || "").toLowerCase().includes(q)
      );
    }
    return list;
  }, [products, activeCat, query]);

  const catName = (slug) => categories.find((c) => c.slug === slug)?.name || slug;
  const years = info?.years ?? 33;

  return (
    <div className="min-h-screen bg-[#f8f6eb]">
      <Navbar />

      {/* HERO */}
      <section id="hero" className="relative bg-gradient-to-br from-[#3b3073] via-[#3b3073] to-[#524a8a] text-[#f8f6eb] overflow-hidden">
        <div className="grain absolute inset-0" />
        <div className="mx-auto max-w-7xl px-6 pt-16 pb-24 lg:pt-24 lg:pb-32 relative">
          <div className="grid lg:grid-cols-12 gap-10 items-center">
            <div className="lg:col-span-7">
              <div className="inline-flex items-center gap-2 bg-[#facb15]/10 border border-[#facb15]/40 text-[#facb15] px-4 py-1.5 rounded-full text-sm font-semibold mb-6">
                {years} anos de história
              </div>
              <h1 className="font-display text-5xl sm:text-6xl lg:text-7xl font-black leading-[0.95] tracking-tight">
                Solução em <span className="text-[#facb15]">Campo</span><br />
                e na <span className="text-[#facb15]">Indústria</span>
              </h1>
              <p className="mt-6 text-lg text-[#f8f6eb]/85 max-w-2xl leading-relaxed">
                Fundada em 1991 em <b className="text-[#facb15]">Araraquara/SP</b>, a Hidrara é líder em soluções industriais com 8 unidades estrategicamente localizadas pelo Brasil. Parceira Parker Hannifin — filtros, bombas, mangueiras e muito mais.
              </p>
              <div className="mt-8 flex flex-wrap gap-3">
                <a href="#contato" data-testid="hero-cta-contact" className="bg-[#facb15] hover:bg-[#e5b800] text-[#3b3073] px-7 py-3.5 rounded-full font-bold transition-colors">
                  Fale Conosco
                </a>
                <a href="#produtos" data-testid="hero-cta-products" className="border-2 border-[#f8f6eb]/40 hover:border-[#facb15] hover:text-[#facb15] px-7 py-3.5 rounded-full font-bold transition-colors">
                  Ver Produtos
                </a>
              </div>
              <div className="mt-12 grid grid-cols-3 gap-6 max-w-2xl">
                <Stat n={`${years}+`} label="Anos de mercado" />
                <Stat n="8" label="Unidades no Brasil" />
                <Stat n="+5K" label="Clientes atendidos" />
              </div>
            </div>
            <div className="lg:col-span-5">
              <div className="relative rounded-3xl overflow-hidden border-4 border-[#facb15]/30 aspect-[4/5] shadow-2xl">
                <img src="/hidrara/scene-harvester.webp" alt="Colheita mecanizada — solução Hidrara em campo" className="w-full h-full object-cover" />
                <div className="absolute inset-0 bg-gradient-to-t from-[#3b3073]/70 via-transparent" />
                <div className="absolute bottom-6 left-6 right-6">
                  <div className="bg-[#f8f6eb]/95 backdrop-blur-md rounded-xl p-4 border border-[#facb15]/40">
                    <div className="text-[10px] uppercase tracking-widest text-[#3b3073]/60 font-bold">Distribuidor autorizado</div>
                    <div className="font-display text-2xl font-black text-[#3b3073]">Parker Hannifin</div>
                    <div className="text-[10px] text-[#3b3073]/70 mt-1">também Mann-Filter · Donaldson Company</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* AUTHORIZED DISTRIBUTORS */}
      <section id="distribuidores" className="py-16 bg-white border-y border-[#3b3073]/10">
        <div className="mx-auto max-w-7xl px-6">
          <div className="text-center max-w-2xl mx-auto mb-10">
            <div className="text-xs uppercase tracking-widest text-[#3b3073]/60 font-bold">Distribuidores Autorizados</div>
            <h3 className="font-display text-3xl lg:text-4xl font-black text-[#3b3073] mt-2">
              Somos <span className="text-[#facb15]">distribuidor oficial</span>
            </h3>
          </div>
          <div className="grid sm:grid-cols-3 gap-4">
            {[
              { name: "Parker Hannifin", tag: "Filtros · Hidráulica · Pneumática" },
              { name: "Mann-Filter", tag: "Filtração automotiva e industrial" },
              { name: "Donaldson Company", tag: "Sistemas de filtração pesados" },
            ].map((d) => (
              <div key={d.name} data-testid={`distributor-${d.name}`} className="rounded-2xl border-2 border-[#facb15] bg-[#f8f6eb] p-6 flex items-center gap-4 hover:shadow-lg transition-shadow">
                <div className="w-14 h-14 rounded-xl bg-[#3b3073] flex items-center justify-center flex-shrink-0">
                  <Award className="w-7 h-7 text-[#facb15]" />
                </div>
                <div>
                  <div className="text-[10px] uppercase tracking-widest text-[#3b3073]/60 font-bold">Distribuidor autorizado</div>
                  <div className="font-display text-xl font-black text-[#3b3073] leading-tight">{d.name}</div>
                  <div className="text-xs text-[#3b3073]/70 mt-0.5">{d.tag}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* MISSION VISION VALUES */}
      <section id="mvv" className="py-20 lg:py-24 bg-[#facb15] relative overflow-hidden" data-testid="mvv-section">
        <div className="grain absolute inset-0" />
        <div className="mx-auto max-w-7xl px-6 relative">
          <div className="grid md:grid-cols-3 gap-10 lg:gap-16">
            {[
              { icon: Target, label: "MISSÃO", text: info?.mission || "" },
              { icon: Eye, label: "VISÃO", text: info?.vision || "" },
              { icon: Star, label: "VALORES", text: info?.values || "" },
            ].map((m, idx) => (
              <div key={m.label} data-testid={`mvv-${m.label.toLowerCase()}`} className="text-center flex flex-col items-center">
                <div className="relative mb-6">
                  {/* curved label */}
                  <svg viewBox="0 0 140 140" className="absolute inset-0 w-full h-full">
                    <defs>
                      <path id={`arc-${idx}`} d="M 20,70 A 50,50 0 0,1 120,70" fill="none" />
                    </defs>
                    <text className="font-display font-black" fill="#3b3073" style={{ fontSize: 20, letterSpacing: 4 }}>
                      <textPath href={`#arc-${idx}`} startOffset="50%" textAnchor="middle">{m.label}</textPath>
                    </text>
                  </svg>
                  <div className="w-[140px] h-[140px] flex items-center justify-center">
                    <div className="w-[92px] h-[92px] rounded-full bg-[#3b3073] flex items-center justify-center mt-4">
                      <m.icon className="w-10 h-10 text-[#facb15]" strokeWidth={2.2} />
                    </div>
                  </div>
                </div>
                <p className="text-[#2a2255] font-semibold leading-relaxed max-w-xs">
                  {m.text}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* SECTORS */}
      <section id="setores" className="py-20 lg:py-28 bg-[#f8f6eb]">
        <div className="mx-auto max-w-7xl px-6">
          <SectionHeader eyebrow="Setores de Atuação" title={<>Soluções para cada <span className="text-[#facb15]">segmento</span></>}
            subtitle="Atendemos aos principais setores da economia, promovendo soluções personalizadas para cada um deles." />
          <div className="mt-14 grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {SECTORS.map((s) => (
              <div key={s.name} data-testid={`sector-${s.name}`} className="bg-white border border-[#3b3073]/10 rounded-2xl p-7 hover:border-[#facb15] hover:shadow-lg transition-all group">
                <div className="w-14 h-14 rounded-xl bg-[#facb15]/10 group-hover:bg-[#facb15] flex items-center justify-center transition-colors mb-5">
                  <s.icon className="w-7 h-7 text-[#3b3073]" />
                </div>
                <h3 className="font-display text-2xl font-bold text-[#3b3073]">{s.name}</h3>
                <p className="text-sm text-[#3b3073]/70 mt-2 leading-relaxed">{s.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* PRODUCTS */}
      <section id="produtos" className="py-20 lg:py-28 bg-[#efeadc]">
        <div className="mx-auto max-w-7xl px-6">
          <SectionHeader eyebrow="Nossa Linha" title={<>Linha de <span className="text-[#facb15]">Produtos</span></>}
            subtitle="Estoque diversificado e alta rotatividade para atender você com agilidade." />

          <div className="mt-12 grid lg:grid-cols-[280px_1fr] gap-8">
            {/* Sidebar Categories */}
            <aside className="lg:sticky lg:top-24 self-start bg-white rounded-2xl border border-[#3b3073]/10 p-5" data-testid="sidebar-categories">
              <div className="text-xs uppercase tracking-widest text-[#3b3073]/60 font-bold mb-3">Categorias</div>
              <div className="flex lg:flex-col flex-row flex-wrap gap-1.5">
                <CatBtn active={activeCat === "all"} onClick={() => setActiveCat("all")} testid="cat-all">
                  Todos os produtos <span className="ml-auto text-xs opacity-60">{products.length}</span>
                </CatBtn>
                {categories.map((c) => {
                  const count = products.filter((p) => p.category === c.slug).length;
                  return (
                    <CatBtn key={c.slug} active={activeCat === c.slug} onClick={() => setActiveCat(c.slug)} testid={`cat-${c.slug}`}>
                      {c.name} <span className="ml-auto text-xs opacity-60">{count}</span>
                    </CatBtn>
                  );
                })}
              </div>
            </aside>

            {/* Search + Grid */}
            <div>
              <div className="relative mb-6">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#3b3073]/50" />
                <Input
                  data-testid="product-search-input"
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="Buscar por nome ou código (ex.: P954208, mangueira, filtro)"
                  className="pl-12 h-14 bg-white border-[#3b3073]/20 focus:border-[#3b3073] text-base rounded-xl"
                />
              </div>

              {loading ? (
                <div className="text-center py-16 text-[#3b3073]/60">Carregando produtos…</div>
              ) : filtered.length === 0 ? (
                <div className="text-center py-16 text-[#3b3073]/60" data-testid="products-empty">
                  Nenhum produto encontrado{query ? ` para "${query}"` : ""}.
                </div>
              ) : (
                <div className="grid sm:grid-cols-2 xl:grid-cols-3 gap-5" data-testid="products-grid">
                  {filtered.map((p) => (
                    <ProductCard key={p.id} product={p} onClick={() => setSelected(p)} />
                  ))}
                </div>
              )}
            </div>
          </div>

          <ProductDetailDialog
            product={selected}
            open={!!selected}
            onOpenChange={(v) => !v && setSelected(null)}
            categoryName={selected ? catName(selected.category) : ""}
          />
        </div>
      </section>

      {/* PROJECTS */}
      <section id="projetos" className="py-20 lg:py-28 bg-[#3b3073] text-[#f8f6eb] relative overflow-hidden">
        <div className="grain absolute inset-0" />
        <div className="mx-auto max-w-7xl px-6 relative">
          <SectionHeader dark eyebrow="Projetos Hidrara" title={<>Soluções <span className="text-[#facb15]">personalizadas</span></>}
            subtitle="Vamos além da venda de peças. Entregamos serviços técnicos e projetos completos." />
          <div className="mt-14 grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {PROJECTS.map((p, i) => (
              <div key={p.title} className="bg-[#f8f6eb]/5 border border-[#f8f6eb]/10 hover:border-[#facb15]/40 rounded-2xl p-6 transition-colors">
                <div className="text-[#facb15] font-mono text-xs mb-4">0{i + 1}</div>
                <h3 className="font-display text-xl font-bold">{p.title}</h3>
                <p className="text-sm text-[#f8f6eb]/70 mt-3 leading-relaxed">{p.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* UNITS */}
      <section id="unidades" className="py-20 lg:py-28 bg-[#f8f6eb]">
        <div className="mx-auto max-w-7xl px-6">
          <SectionHeader eyebrow="Nossas Unidades" title={<>Presença em <span className="text-[#facb15]">todo o Brasil</span></>}
            subtitle="8 unidades estrategicamente localizadas para atender você com agilidade." />

          {/* Featured MATRIZ card with facade photo */}
          {info?.units?.find((u) => u.role === "MATRIZ") && (
            <div className="mt-12 grid lg:grid-cols-[1fr_1fr] gap-6 items-stretch bg-[#3b3073] text-[#f8f6eb] rounded-3xl overflow-hidden border-2 border-[#facb15]">
              <div className="relative aspect-[4/3] lg:aspect-auto">
                <img src="/hidrara/facade-araraquara.jpg" alt="Fachada da Matriz Hidrara — Araraquara/SP" className="absolute inset-0 w-full h-full object-cover" />
              </div>
              <div className="p-8 lg:p-12 flex flex-col justify-center">
                <div className="inline-flex items-center gap-2 bg-[#facb15] text-[#3b3073] text-[10px] font-black tracking-widest px-3 py-1.5 rounded-full self-start">
                  MATRIZ · DESDE 1991
                </div>
                <h3 className="font-display text-4xl lg:text-6xl font-black text-[#facb15] mt-4 leading-none">Araraquara<span className="text-[#f8f6eb]/60 text-2xl lg:text-3xl ml-2">/SP</span></h3>
                <p className="mt-4 text-[#f8f6eb]/85 leading-relaxed">
                  Fundada em 1991 em Araraquara, a Hidrara nasceu para atender o setor sucroalcooleiro e cresceu ao longo dos anos consolidando-se como parceira estratégica das principais usinas e indústrias do país.
                </p>
                <div className="mt-6 flex flex-wrap gap-6 pt-6 border-t border-[#facb15]/20">
                  <div>
                    <div className="text-[10px] uppercase tracking-widest text-[#facb15]/80">Endereço</div>
                    <div className="text-sm mt-0.5">{info.units.find(u => u.role === "MATRIZ").address}</div>
                  </div>
                  <div>
                    <div className="text-[10px] uppercase tracking-widest text-[#facb15]/80">Telefone</div>
                    <div className="text-sm mt-0.5 font-mono font-semibold">{info.units.find(u => u.role === "MATRIZ").phone}</div>
                  </div>
                </div>
              </div>
            </div>
          )}

          <div className="mt-8 grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {(info?.units || []).filter(u => u.role !== "MATRIZ").map((u) => (
              <div
                key={`${u.city}-${u.state}`}
                data-testid={`unit-${u.city}`}
                className="rounded-2xl p-5 border bg-white border-[#3b3073]/10 hover:border-[#facb15] transition-all"
              >
                <div className="flex items-center justify-between mb-3">
                  <span className="text-[10px] font-black tracking-widest px-2 py-1 rounded bg-[#3b3073]/10 text-[#3b3073]">
                    {u.role}
                  </span>
                  <span className="text-xs font-semibold text-[#3b3073]/60">{u.state}</span>
                </div>
                <h3 className="font-display text-2xl font-bold text-[#3b3073]">{u.city}</h3>
                <p className="text-xs mt-2 leading-relaxed text-[#3b3073]/70">{u.address}</p>
                <div className="mt-4 pt-3 border-t border-[#3b3073]/10">
                  <div className="text-sm font-mono font-semibold flex items-center gap-1.5 text-[#3b3073]">
                    <Phone className="w-3.5 h-3.5" /> {u.phone}
                  </div>
                </div>
              </div>
            ))}
            {/* Keep Araraquara card in grid too for test compatibility (hidden visually) */}
            {info?.units?.find((u) => u.role === "MATRIZ") && (
              <div data-testid="unit-Araraquara" className="hidden" aria-hidden="true">MATRIZ Araraquara</div>
            )}
          </div>
        </div>
      </section>

      {/* CLIENTS */}
      <section className="py-20 lg:py-28 bg-[#f8f6eb] border-t border-[#3b3073]/5">
        <div className="mx-auto max-w-7xl px-6">
          <SectionHeader eyebrow="Nossos Clientes" title={<>Confiança de quem <span className="text-[#facb15]">gera o Brasil</span></>}
            subtitle="Atendemos as principais usinas, indústrias de papel e celulose, agroindústrias e grupos do agronegócio nacional." />
          <div className="mt-14 grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
            {CLIENTS.map((c) => (
              <div key={c.name} className="bg-white border border-[#3b3073]/10 rounded-xl h-24 flex items-center justify-center p-4 hover:border-[#facb15] hover:shadow-md transition-all grayscale hover:grayscale-0" title={c.name}>
                <img src={c.src} alt={c.name} className="max-h-full max-w-full object-contain" loading="lazy" />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* BRANDS marquee */}
      <section className="py-16 bg-[#efeadc] border-y border-[#3b3073]/10">
        <div className="mx-auto max-w-7xl px-6">
          <div className="text-center mb-8">
            <div className="text-xs uppercase tracking-widest text-[#3b3073]/60 font-bold">Marcas Parceiras</div>
            <h3 className="font-display text-3xl lg:text-4xl font-black text-[#3b3073] mt-2">Trabalhamos com as <span className="text-[#facb15]">melhores marcas</span></h3>
          </div>
          <div className="overflow-hidden relative">
            <div className="marquee-track flex gap-4 w-max">
              {[...BRANDS, ...BRANDS].map((b, i) => (
                <div key={i} className="bg-white border border-[#3b3073]/10 rounded-xl px-8 py-4 font-display font-bold text-lg text-[#3b3073] whitespace-nowrap">
                  {b}
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* TESTIMONIALS */}
      <section className="py-20 lg:py-28 bg-[#f8f6eb]">
        <div className="mx-auto max-w-7xl px-6">
          <SectionHeader eyebrow="Depoimentos" title={<>O que dizem nossos <span className="text-[#facb15]">clientes</span></>} />
          <div className="mt-14 grid md:grid-cols-3 gap-5">
            {TESTIMONIALS.map((t) => (
              <div key={t.name} className="bg-white border border-[#3b3073]/10 rounded-2xl p-7 relative">
                <div className="text-6xl font-display text-[#facb15] leading-none">&ldquo;</div>
                <p className="text-[#3b3073]/80 leading-relaxed -mt-4">{t.text}</p>
                <div className="mt-6 pt-4 border-t border-[#3b3073]/10">
                  <div className="font-display font-bold text-[#3b3073]">{t.name}</div>
                  <div className="text-xs text-[#3b3073]/60">{t.role}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CONTACT */}
      <section id="contato" className="py-20 lg:py-28 bg-gradient-to-br from-[#3b3073] to-[#2a2255] text-[#f8f6eb]">
        <div className="mx-auto max-w-7xl px-6">
          <div className="grid lg:grid-cols-2 gap-14">
            <div>
              <div className="text-xs uppercase tracking-widest text-[#facb15] font-bold">Contato</div>
              <h2 className="font-display text-4xl lg:text-6xl font-black mt-3">Fale com a <span className="text-[#facb15]">Hidrara</span></h2>
              <p className="mt-4 text-[#f8f6eb]/80 max-w-lg leading-relaxed">Solicite orçamento, tire dúvidas ou peça suporte técnico. Estamos prontos para atender.</p>
              <div className="mt-8 space-y-4">
                <ContactRow icon={Phone} title="WhatsApp / Atendimento" value={info?.phone_commercial || "(16) 3508-1300"} href={WA_URL} />
                <ContactRow icon={Mail} title="E-mail" value={info?.email || "contato@hidrara.com.br"} href="mailto:contato@hidrara.com.br" />
                <ContactRow icon={Clock} title="Horário" value="Seg a Sex: 08h às 18h" />
                <ContactRow icon={MapPin} title="Matriz" value="Araraquara / SP" />
              </div>
            </div>
            <ContactForm />
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="bg-[#2a2255] text-[#f8f6eb] py-14 border-t border-[#f8f6eb]/10">
        <div className="mx-auto max-w-7xl px-6">
          <div className="grid md:grid-cols-4 gap-10">
            <div className="md:col-span-2">
              <span className="inline-flex items-center bg-[#f8f6eb] rounded-lg px-3 py-2 shadow-md mb-4">
                <img
                  src="/hidrara/logo.jpg"
                  alt="Hidrara — A sua solução em campo"
                  className="h-10 w-auto"
                />
              </span>
              <p className="text-[#f8f6eb]/70 text-sm max-w-md leading-relaxed">Líder em soluções industriais, atendendo o Brasil há mais de {years} anos com foco em filtros e bombas hidráulicas. Matriz em Araraquara/SP desde 1991.</p>
              <div className="mt-6">
                <Link to="/admin/login" data-testid="footer-admin-link" className="text-xs text-[#f8f6eb]/50 hover:text-[#facb15] underline underline-offset-4">
                  Acesso administrativo
                </Link>
              </div>
            </div>
            <div>
              <div className="font-display font-bold mb-3 text-[#facb15]">Navegação</div>
              <ul className="space-y-2 text-sm text-[#f8f6eb]/70">
                <li><a href="#hero" className="hover:text-[#facb15]">Início</a></li>
                <li><a href="#setores" className="hover:text-[#facb15]">Setores</a></li>
                <li><a href="#produtos" className="hover:text-[#facb15]">Produtos</a></li>
                <li><a href="#projetos" className="hover:text-[#facb15]">Projetos</a></li>
                <li><a href="#unidades" className="hover:text-[#facb15]">Unidades</a></li>
              </ul>
            </div>
            <div>
              <div className="font-display font-bold mb-3 text-[#facb15]">Contato</div>
              <ul className="space-y-2 text-sm text-[#f8f6eb]/70">
                <li>WhatsApp / Atendimento</li>
                <li>{info?.phone_commercial || "(16) 3508-1300"}</li>
                <li>{info?.email || "contato@hidrara.com.br"}</li>
                <li>8 unidades pelo Brasil</li>
              </ul>
            </div>
          </div>
          <div className="mt-10 pt-6 border-t border-[#f8f6eb]/10 flex flex-wrap items-center justify-between gap-3 text-xs text-[#f8f6eb]/50">
            <div>© {new Date().getFullYear()} Hidrara Conexões. Todos os direitos reservados.</div>
            <div>Solução em Campo e na Indústria</div>
          </div>
        </div>
      </footer>
    </div>
  );
}

function Stat({ n, label }) {
  return (
    <div>
      <div className="font-display text-4xl lg:text-5xl font-black text-[#facb15]">{n}</div>
      <div className="text-xs uppercase tracking-widest text-[#f8f6eb]/60 mt-1">{label}</div>
    </div>
  );
}

function SectionHeader({ eyebrow, title, subtitle, dark }) {
  return (
    <div className="max-w-3xl">
      <div className={`text-xs uppercase tracking-widest font-bold ${dark ? "text-[#facb15]" : "text-[#3b3073]/60"}`}>{eyebrow}</div>
      <h2 className={`font-display text-4xl sm:text-5xl lg:text-6xl font-black mt-3 leading-tight ${dark ? "text-[#f8f6eb]" : "text-[#3b3073]"}`}>{title}</h2>
      {subtitle && <p className={`mt-4 text-lg leading-relaxed ${dark ? "text-[#f8f6eb]/75" : "text-[#3b3073]/75"}`}>{subtitle}</p>}
    </div>
  );
}

function CatBtn({ active, children, onClick, testid }) {
  return (
    <button
      type="button"
      data-testid={testid}
      onClick={onClick}
      className={`w-full flex items-center text-left text-sm px-4 py-2.5 rounded-lg font-medium transition-colors ${
        active ? "bg-[#3b3073] text-[#f8f6eb]" : "hover:bg-[#3b3073]/5 text-[#3b3073]"
      }`}
    >
      {children}
    </button>
  );
}

function ContactRow({ icon: Icon, title, value, href }) {
  const inner = (
    <div className="flex items-start gap-4 group">
      <div className="w-11 h-11 rounded-xl bg-[#facb15]/10 group-hover:bg-[#facb15] flex items-center justify-center transition-colors flex-shrink-0">
        <Icon className="w-5 h-5 text-[#facb15] group-hover:text-[#3b3073] transition-colors" />
      </div>
      <div>
        <div className="text-xs uppercase tracking-widest text-[#facb15] font-bold">{title}</div>
        <div className="text-lg font-display font-bold mt-0.5">{value}</div>
      </div>
    </div>
  );
  return href ? <a href={href} target="_blank" rel="noreferrer">{inner}</a> : inner;
}

function ContactForm() {
  const [form, setForm] = useState({ name: "", phone: "", email: "", message: "" });
  const [sending, setSending] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setSending(true);
    try {
      await api.post("/contact", form);
      toast.success("Mensagem enviada! Retornaremos em breve.");
      setForm({ name: "", phone: "", email: "", message: "" });
    } catch (err) {
      toast.error(formatApiError(err));
    } finally {
      setSending(false);
    }
  };
  return (
    <form onSubmit={submit} className="bg-[#f8f6eb]/5 backdrop-blur-md border border-[#f8f6eb]/20 rounded-2xl p-8" data-testid="contact-form">
      <h3 className="font-display text-2xl font-bold mb-6">Envie sua mensagem</h3>
      <div className="space-y-4">
        <Field label="Nome *" value={form.name} onChange={(v) => setForm({ ...form, name: v })} required testid="contact-name" />
        <Field label="Telefone" value={form.phone} onChange={(v) => setForm({ ...form, phone: v })} testid="contact-phone" />
        <Field label="E-mail *" type="email" value={form.email} onChange={(v) => setForm({ ...form, email: v })} required testid="contact-email" />
        <div>
          <label className="text-xs uppercase tracking-widest text-[#facb15] font-bold">Mensagem *</label>
          <textarea
            data-testid="contact-message"
            required
            rows={4}
            value={form.message}
            onChange={(e) => setForm({ ...form, message: e.target.value })}
            className="mt-2 w-full bg-[#f8f6eb]/10 border border-[#f8f6eb]/20 rounded-lg px-4 py-3 text-[#f8f6eb] placeholder:text-[#f8f6eb]/40 focus:border-[#facb15] outline-none"
          />
        </div>
        <Button type="submit" data-testid="contact-submit" disabled={sending} className="w-full bg-[#facb15] hover:bg-[#e5b800] text-[#3b3073] font-bold h-12 rounded-full">
          {sending ? "Enviando..." : "Enviar Mensagem"}
        </Button>
      </div>
    </form>
  );
}

function Field({ label, value, onChange, type = "text", required, testid }) {
  return (
    <div>
      <label className="text-xs uppercase tracking-widest text-[#facb15] font-bold">{label}</label>
      <input
        data-testid={testid}
        type={type}
        required={required}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="mt-2 w-full bg-[#f8f6eb]/10 border border-[#f8f6eb]/20 rounded-lg px-4 py-3 text-[#f8f6eb] placeholder:text-[#f8f6eb]/40 focus:border-[#facb15] outline-none"
      />
    </div>
  );
}
