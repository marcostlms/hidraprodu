import React from "react";
import { resolveImage } from "@/lib/api";
import { Badge } from "@/components/ui/badge";

export default function ProductCard({ product, onClick }) {
  const img = resolveImage(product.image_url);
  return (
    <button
      type="button"
      data-testid={`product-card-${product.code}`}
      onClick={onClick}
      className="product-card group text-left bg-white rounded-2xl overflow-hidden border border-[#3b3073]/10 flex flex-col"
    >
      <div className="aspect-[4/3] bg-[#efeadc] overflow-hidden relative">
        {img ? (
          <img
            src={img}
            alt={product.name}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
            loading="lazy"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-[#3b3073]/40 font-display text-xl">
            Sem imagem
          </div>
        )}
        {product.featured && (
          <span className="absolute top-3 left-3 bg-[#facb15] text-[#3b3073] text-xs font-bold px-2.5 py-1 rounded-full">
            DESTAQUE
          </span>
        )}
      </div>
      <div className="p-5 flex flex-col gap-2 flex-1">
        <div className="flex items-center justify-between gap-2">
          <span className="text-xs font-mono font-semibold text-[#3b3073]/60 tracking-wider" data-testid={`product-code-${product.code}`}>
            {product.code}
          </span>
          {product.brand && (
            <Badge variant="outline" className="border-[#3b3073]/20 text-[#3b3073]/70 text-[10px]">
              {product.brand}
            </Badge>
          )}
        </div>
        <h3 className="font-display font-bold text-lg text-[#3b3073] leading-tight">
          {product.name}
        </h3>
        {product.description && (
          <p className="text-sm text-[#3b3073]/70 line-clamp-2 mt-auto">
            {product.description}
          </p>
        )}
      </div>
    </button>
  );
}
