import React from "react";
import { Link } from "react-router-dom";

export default function Navbar({ transparent = false }) {
  const bg = transparent ? "bg-transparent" : "bg-[#3b3073]";
  return (
    <header className={`${bg} text-[#f8f6eb] sticky top-0 z-40 border-b border-[#f8f6eb]/10`}>
      <div className="mx-auto max-w-7xl px-6 py-3 flex items-center justify-between">
        <Link to="/" className="flex items-center" data-testid="nav-logo">
          <span className="inline-flex items-center bg-[#f8f6eb] rounded-lg px-3 py-1.5 shadow-md">
            <img
              src="/hidrara/logo.jpg"
              alt="Hidrara — A sua solução em campo"
              className="h-9 lg:h-10 w-auto"
            />
          </span>
        </Link>
        <nav className="hidden lg:flex items-center gap-8 text-sm font-medium">
          <a href="#hero" className="hover:text-[#facb15] transition-colors">Início</a>
          <a href="#mvv" className="hover:text-[#facb15] transition-colors">Sobre</a>
          <a href="#setores" className="hover:text-[#facb15] transition-colors">Setores</a>
          <a href="#produtos" className="hover:text-[#facb15] transition-colors">Produtos</a>
          <a href="#projetos" className="hover:text-[#facb15] transition-colors">Projetos</a>
          <a href="#unidades" className="hover:text-[#facb15] transition-colors">Unidades</a>
          <a href="#contato" className="hover:text-[#facb15] transition-colors">Contato</a>
        </nav>
        <a
          href="#contato"
          data-testid="nav-cta"
          className="hidden sm:inline-flex items-center gap-2 bg-[#facb15] hover:bg-[#e5b800] text-[#3b3073] px-5 py-2.5 rounded-full font-semibold text-sm transition-colors"
        >
          Fale Conosco
        </a>
      </div>
    </header>
  );
}
