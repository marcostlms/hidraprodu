import React from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { resolveImage } from "@/lib/api";

export default function ProductDetailDialog({ product, open, onOpenChange, categoryName }) {
  if (!product) return null;
  const img = resolveImage(product.image_url);
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl bg-white" data-testid="product-detail-dialog">
        <DialogHeader>
          <div className="flex flex-wrap items-center gap-2 mb-1">
            <span className="text-xs font-mono font-semibold text-[#3b3073]/60 tracking-wider">
              {product.code}
            </span>
            {product.brand && <Badge className="bg-[#3b3073] text-[#f8f6eb] hover:bg-[#3b3073]">{product.brand}</Badge>}
            {categoryName && <Badge variant="outline" className="border-[#3b3073]/30">{categoryName}</Badge>}
          </div>
          <DialogTitle className="font-display text-3xl text-[#3b3073] text-left">
            {product.name}
          </DialogTitle>
          <DialogDescription className="sr-only">Detalhes do produto</DialogDescription>
        </DialogHeader>
        <div className="grid md:grid-cols-2 gap-6">
          <div className="aspect-square bg-[#efeadc] rounded-xl overflow-hidden">
            {img ? (
              <img src={img} alt={product.name} className="w-full h-full object-cover" />
            ) : (
              <div className="w-full h-full flex items-center justify-center text-[#3b3073]/40">Sem imagem</div>
            )}
          </div>
          <div className="space-y-4">
            <div>
              <div className="text-xs uppercase tracking-wider text-[#3b3073]/60 mb-1">Descrição técnica</div>
              <p className="text-[#3b3073]/80 leading-relaxed">
                {product.description || "Consulte-nos para especificações completas."}
              </p>
            </div>
            <div className="pt-4 border-t border-[#3b3073]/10">
              <div className="text-xs uppercase tracking-wider text-[#3b3073]/60 mb-2">Solicite este item</div>
              <div className="flex flex-wrap gap-2">
                <a
                  href={`https://wa.me/551635081300?text=${encodeURIComponent(`Olá! Vim pelo site da Hidrara e tenho interesse no produto ${product.code} — ${product.name}. Poderia me ajudar?`)}`}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-2 bg-[#25D366] hover:bg-[#1fb058] text-white px-4 py-2.5 rounded-full font-semibold text-sm"
                  data-testid="product-whatsapp"
                >
                  WhatsApp Atendimento
                </a>
                <a
                  href="mailto:contato@hidrara.com.br"
                  className="inline-flex items-center gap-2 bg-[#3b3073] hover:bg-[#2a2255] text-[#f8f6eb] px-4 py-2.5 rounded-full font-semibold text-sm"
                >
                  E-mail Comercial
                </a>
              </div>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
