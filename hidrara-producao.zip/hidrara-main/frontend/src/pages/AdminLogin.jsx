import React, { useState } from "react";
import { Navigate, useNavigate, Link } from "react-router-dom";
import { useAuth } from "@/context/AuthContext";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Lock, Mail, ArrowLeft } from "lucide-react";

export default function AdminLogin() {
  const { user, login, loading } = useAuth();
  const nav = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [submitting, setSubmitting] = useState(false);

  if (loading) return <div className="min-h-screen bg-[#3b3073]" />;
  if (user) return <Navigate to="/admin" replace />;

  const submit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    const r = await login(email, password);
    setSubmitting(false);
    if (r.ok) {
      toast.success("Bem-vindo, administrador");
      nav("/admin");
    } else {
      toast.error(r.error || "Falha ao entrar");
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#3b3073] via-[#2a2255] to-[#3b3073] flex items-center justify-center px-6 relative overflow-hidden">
      <div className="grain absolute inset-0" />
      <Link to="/" className="absolute top-6 left-6 text-[#f8f6eb]/70 hover:text-[#facb15] flex items-center gap-2 text-sm">
        <ArrowLeft className="w-4 h-4" /> Voltar ao site
      </Link>
      <div className="relative bg-[#f8f6eb] rounded-3xl w-full max-w-md p-10 shadow-2xl border-4 border-[#facb15]/40">
        <div className="flex items-center gap-3 mb-6 pb-6 border-b border-[#3b3073]/10">
          <img src="/hidrara/logo.jpg" alt="Hidrara" className="h-14 w-auto rounded" />
          <div className="text-[10px] uppercase tracking-widest text-[#3b3073]/60 font-bold">
            Painel<br/>Administrativo
          </div>
        </div>
        <h1 className="font-display text-3xl font-black text-[#3b3073]">Acesso restrito</h1>
        <p className="text-sm text-[#3b3073]/60 mt-1">Entre com suas credenciais de administrador.</p>
        <form onSubmit={submit} className="mt-6 space-y-4">
          <div>
            <Label className="text-[#3b3073] font-semibold">E-mail</Label>
            <div className="relative mt-2">
              <Mail className="w-4 h-4 text-[#3b3073]/40 absolute left-3 top-1/2 -translate-y-1/2" />
              <Input
                data-testid="admin-login-email"
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="admin@hidrara.com.br"
                className="pl-9 h-12 bg-white border-[#3b3073]/20 focus:border-[#3b3073] text-[#3b3073]"
              />
            </div>
          </div>
          <div>
            <Label className="text-[#3b3073] font-semibold">Senha</Label>
            <div className="relative mt-2">
              <Lock className="w-4 h-4 text-[#3b3073]/40 absolute left-3 top-1/2 -translate-y-1/2" />
              <Input
                data-testid="admin-login-password"
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="pl-9 h-12 bg-white border-[#3b3073]/20 focus:border-[#3b3073] text-[#3b3073]"
              />
            </div>
          </div>
          <Button
            data-testid="admin-login-submit"
            disabled={submitting}
            type="submit"
            className="w-full h-12 bg-[#3b3073] hover:bg-[#2a2255] text-[#facb15] font-bold rounded-full"
          >
            {submitting ? "Entrando..." : "Entrar no painel"}
          </Button>
        </form>
      </div>
    </div>
  );
}
